/* Replace with your SQL commands */
TRUNCATE TABLE address;