/* Replace with your SQL commands */
INSERT INTO public.adress(adress,cordinates,path,"time","date") VALUES ('342,first floor,ranchi','apna/tower/bhawarkuaa','(10,14,15,26)','11:00:00','2020-01-01');
INSERT INTO public.adress(adress,cordinates,path,"time","date")VALUES( '45, yn marg hello point,first floor,mumbai', 'apna/tower/bhawarkuaa', '(102,17,15,96)', '10:00:00', '2020-01-01');
INSERT INTO public.adress(adress,cordinates,path,"time","date")VALUES('342,nx colltertratefirst floor,mp', 'apna/tower/bhawarkuaa', '(1,104,19,26)', '10:00:00', '2020-01-01');
