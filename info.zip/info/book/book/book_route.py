import logging
import datetime

from flask import request, jsonify
from book import app, db
from flask_cors import cross_origin
from book.model import AddressBook

logging.basicConfig(filename='logs.log', level=logging.INFO)

''' DATE FORMATE FOR AddressBook '''


def get_date(input_date):
    split_date = input_date.split("-")
    day = split_date[1]
    month = split_date[1]
    year = split_date[2]

    final_date = datetime.date(int(year), int(month), int(day))
    return final_date


'''CRUD OPERATIONS OF AddressBook '''


@app.route("/book/api/lab", methods=['GET', 'OPTIONS'])
@cross_origin(origin='*', headers=['Content-Type', 'Authorization'])
def get_lab(*args):
    data = AddressBook.query.all()
    result = []
    for book_data in data:
        book_result = {}
        book_result['id'] = book_data.id
        book_result['adress'] = book_data.adress
        book_result['time'] = str(book_data.time)
        book_result['date'] = str(book_data.date)
        book_result['cordinates'] = book_data.cordinates
        book_result['path'] = book_data.path
        result.append(book_result)
    return jsonify({'result': result})


'''lab post api'''


@app.route('/book/api/add_book', methods=['POST'])
@cross_origin(origin='*', headers=['Content-Type', 'Authorization'])
def add_exam(*args):
    book_add = request.get_json()
    adress = book_add['test_type']
    date = book_add['date']
    lab_add_date_formate = get_date(date)
    time = book_add['time']
    path = book_add['path']
    cordinates = book_add['cordinates']
    book_data = AddressBook(adress=adress, date=date, time=time, cordinates=cordinates, path=path)
    db.session.add(book_data)
    db.session.commit()
    return "succesffully entered"


'''Lab put api'''


@app.route("/book/api/book/update/<id>", methods=['PUT', 'OPTIONS'])
@cross_origin(origin='*', headers=['Content-Type', 'Authorization'])
def get_lab_update(*args, id):
    request_data = request.get_json()
    adress = request_data['adress']
    time = request_data['time']
    date = request_data['date']
    cordinates = request_data['cordinates']
    path = request_data['path']
    request_data = AddressBook.query.filter_by(id=id).first()
    if not request_data:
        return jsonify({'message ': 'No user found'})
    request_data.time = time
    request_data.date = date
    request_data.cordinates = cordinates
    request_data.adress = adress
    request_data.path = path
    db.session.commit()
    return jsonify({'lab updated successfully': request_data.id})


'''address schedule delete api'''


@app.route("/book/api/lab/delete/<id>", methods=['DELETE', 'OPTIONS'])
@cross_origin(origin='*', headers=['Content-Type', 'Authorization'])
def lab_delete(*args, id):
    address_data = AddressBook.query.filter_by(id=id).first()
    print(address_data)
    if not address_data:
        return jsonify({'message ': 'No data found'})
    db.session.delete(address_data)
    db.session.commit()
    return jsonify({'candidate_deleted_successfully': address_data.id})
