/* Replace with your SQL commands */
CREATE TABLE public.laboratory (
	id serial4 NOT NULL,
	test_type varchar NOT NULL,
	doctor varchar NULL,
	patient varchar NULL,
	"time" time NOT NULL,
	"date" date NOT NULL,
	CONSTRAINT laboratory_pkey PRIMARY KEY (id)
);