

from book import db


class AddressBook(db.Model):
    __tablename__ = 'address'
    id = db.Column(db.Integer, primary_key=True)
    adress = db.Column('test_type',db.String, nullable= True)
    date = db.Column('date', db.Date, nullable=False)
    time = db.Column('time', db.Time, nullable=False)
    cordinates = db.Column(db.Integer,nullable=True)
    path = db.Column(db.String,nullable=True)
